// 云函数入口文件
const cloud = require("wx-server-sdk");
var AipImageClassifyClient = require("baidu-aip-sdk").imageClassify;

// 设置APPID/AK/SK
var APP_ID = "18521912";
var API_KEY = "Pvj5NvjunoOF8TFpSI9Pv5oj";
var SECRET_KEY = "DonZ4ulWGSXydYkcvTh99tXsKzH6KB2j";

cloud.init();

var client = new AipImageClassifyClient(APP_ID, API_KEY, SECRET_KEY);

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext();
  const { fileID } = event;

  //云函数里调用云存储
  const res = await cloud.downloadFile({
    fileID: fileID,
  });

  const buffer = res.fileContent;
  const image = buffer.toString("base64");
  const info = await client.plantDetect(image, { baike_num: 5 });
  return {
    info,
    event,
    openid: wxContext.OPENID,
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID,
  };
};
