// miniprogram/pages/flower/flower.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  doUpLoad:function(event){
    console.log(event)
    let sourceType = "album";
    let {target} = event ;
    let {dataset} = target;
    let {index} = dataset;
    if(index == 0){
      sourceType = "camera"
    }else{
      sourceType = "album"
    }
    wx.chooseImage({
      count:1,
      sizeType:['original', 'compressed'],
      sourceType:[sourceType],
      success:res=>{
        console.log(res)
        let filePath = res.tempFilePaths[0];
        //云存储不可以有相同的名称
        let cloudPath = `mp16/${Date.now()}${filePath.match(/.[^.]+?$/)}`
        wx.cloud.uploadFile({
          cloudPath,
          filePath,
          success:ress=>{
            console.log(ress)
            
            wx.navigateTo({
              url: `../picInfo/picInfo?fileID=${ress.fileID}&pic=${filePath}`,
            })
          }
        })
      },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})