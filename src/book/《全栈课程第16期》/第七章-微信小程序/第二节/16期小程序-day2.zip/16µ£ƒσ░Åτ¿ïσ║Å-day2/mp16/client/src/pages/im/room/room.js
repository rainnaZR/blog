import { Block, View } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import Chatroom from '../../../components/chatroom/chatroom'
import './room.scss'
const app = Taro.getApp()

@withWeapp({
  data: {
    avatarUrl: './user-unlogin.png',
    userInfo: null,
    logged: false,
    takeSession: false,
    requestResult: '',
    // chatRoomEnvId: 'release-f8415a',
    chatRoomCollection: 'chatroom',
    chatRoomGroupId: 'demo',
    chatRoomGroupName: '聊天室',

    // functions for used in chatroom components
    onGetUserInfo: null,
    getOpenID: null
  },

  onLoad: function() {
    // 获取用户信息
    Taro.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          Taro.getUserInfo({
            success: res => {
              this.setData({
                avatarUrl: res.userInfo.avatarUrl,
                userInfo: res.userInfo
              })
            }
          })
        }
      }
    })

    this.setData({
      onGetUserInfo: this.onGetUserInfo,
      getOpenID: this.getOpenID
    })

    Taro.getSystemInfo({
      success: res => {
        console.log('system info', res)
        if (res.safeArea) {
          const { top, bottom } = res.safeArea
          this.setData({
            containerStyle: `padding-top: ${(/ios/i.test(res.system)
              ? 10
              : 20) + top}px; padding-bottom: ${20 +
              res.windowHeight -
              bottom}px`
          })
        }
      }
    })
  },

  getOpenID: async function() {
    if (this.openid) {
      return this.openid
    }

    const { result } = await Taro.cloud.callFunction({
      name: 'login'
    })

    return result.openid
  },

  onGetUserInfo: function(e) {
    if (!this.logged && e.detail.userInfo) {
      this.setData({
        logged: true,
        avatarUrl: e.detail.userInfo.avatarUrl,
        userInfo: e.detail.userInfo
      })
    }
  },

  onShareAppMessage() {
    return {
      title: '即时通信 Demo',
      path: '/pages/im/room/room'
    }
  }
})
class _C extends Taro.Component {
  config = {}

  render() {
    const {
      containerStyle,
      chatRoomEnvId,
      chatRoomCollection,
      chatRoomGroupId,
      chatRoomGroupName,
      userInfo,
      onGetUserInfo,
      getOpenID
    } = this.data
    return (
      <View className="container" style={containerStyle}>
        <Chatroom
          style="width: 100%; height: 100%"
          envId={chatRoomEnvId}
          collection={chatRoomCollection}
          groupId={chatRoomGroupId}
          groupName={chatRoomGroupName}
          userInfo={userInfo}
          onGetUserInfo={onGetUserInfo}
          getOpenId={getOpenID}
        ></Chatroom>
      </View>
    )
  }
}

export default _C
