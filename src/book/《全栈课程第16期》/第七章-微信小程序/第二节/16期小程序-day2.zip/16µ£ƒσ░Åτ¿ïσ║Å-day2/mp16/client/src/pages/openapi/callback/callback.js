import { Block, View, Button, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './callback.scss'

@withWeapp({
  data: {},

  onLoad: function(options) {},

  onCustomerServiceButtonClick(e) {
    console.log(e)
  }
})
class _C extends Taro.Component {
  config = {}

  render() {
    return (
      <View className="container">
        <View className="list">
          <Button
            openType="contact"
            onContact={this.onCustomerServiceButtonClick}
          >
            进入客服消息
          </Button>
        </View>
        <View className="guide">
          <Text className="headline">测试须知</Text>
          <Text className="p">
            1. 进入云开发控制台“设置-全局设置”，选择添加消息推送配置
          </Text>
          <Text className="p">2. 消息类型选择 text（文本客户消息）</Text>
          <Text className="p">3. 事件类型选择空</Text>
          <Text className="p">4. 选择需要推送到哪个环境的哪个云函数</Text>
          <Text className="p">5. 在手机上测试</Text>
        </View>
      </View>
    )
  }
} // miniprogram/pages/openapi/callback/callback.js

export default _C
