import { Block } from "@tarojs/components";
import Taro from "@tarojs/taro";
import withWeapp from "@tarojs/with-weapp";
import "taro-ui/dist/style/index.scss";
import "./app.scss";

@withWeapp({
  onLaunch: function () {
    if (!Taro.cloud) {
      console.error("请使用 2.2.3 或以上的基础库以使用云能力");
    } else {
      Taro.cloud.init({
        // env 参数说明：
        //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
        //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
        //   如不填则使用默认环境（第一个创建的环境）
        // env: 'my-env-id',
        traceUser: true,
      });
    }

    this.globalData = {};
  },
})
class App extends Taro.Component {
  config = {
    pages: [
      "pages/books/books",
      "pages/book/book",
      "pages/index/index",
      "pages/userConsole/userConsole",
      "pages/storageConsole/storageConsole",
      "pages/databaseGuide/databaseGuide",
      "pages/addFunction/addFunction",
      "pages/deployFunctions/deployFunctions",
      "pages/chooseLib/chooseLib",
      "pages/openapi/openapi",
      "pages/openapi/serverapi/serverapi",
      "pages/openapi/callback/callback",
      "pages/openapi/cloudid/cloudid",
      "pages/im/im",
      "pages/im/room/room",
    ],
    window: {
      backgroundColor: "#F6F6F6",
      backgroundTextStyle: "light",
      navigationBarBackgroundColor: "#F6F6F6",
      navigationBarTitleText: "云开发 QuickStart",
      navigationBarTextStyle: "black",
    },
    sitemapLocation: "sitemap.json",
    style: "v2",
  };

  render() {
    return null;
  }
} //app.js

export default App;
Taro.render(<App />, document.getElementById("app"));
