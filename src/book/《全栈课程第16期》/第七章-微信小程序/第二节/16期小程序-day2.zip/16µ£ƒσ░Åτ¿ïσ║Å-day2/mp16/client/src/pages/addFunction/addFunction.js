import { Block, View, Text, Image, Button } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './addFunction.scss'
// pages/addFunction/addFunction.js

const code = `// 云函数入口函数
exports.main = async (event, context) => {
  console.log(event)
  console.log(context)
  return {
    sum: event.a + event.b
  }
}`

@withWeapp({
  data: {
    result: '',
    canIUseClipboard: Taro.canIUse('setClipboardData')
  },

  onLoad: function(options) {},

  copyCode: function() {
    Taro.setClipboardData({
      data: code,
      success: function() {
        Taro.showToast({
          title: '复制成功'
        })
      }
    })
  },

  testFunction() {
    Taro.cloud.callFunction({
      name: 'sum',
      data: {
        a: 1,
        b: 2
      },
      success: res => {
        Taro.showToast({
          title: '调用成功'
        })
        this.setData({
          result: JSON.stringify(res.result)
        })
      },
      fail: err => {
        Taro.showToast({
          icon: 'none',
          title: '调用失败'
        })
        console.error('[云函数] [sum] 调用失败：', err)
      }
    })
  }
})
class _C extends Taro.Component {
  config = {
    navigationBarTitleText: '云函数指引'
  }

  render() {
    const { result, canIUseClipboard } = this.data
    return (
      <View className="container">
        <View className="list">
          <View className="list-item" onClick={this.testFunction}>
            <Text>测试云函数</Text>
          </View>
          <View className="list-item">
            <Text className="request-text">
              期望输出：{'{'}"sum":3{'}'}
            </Text>
          </View>
          {result && (
            <View className="list-item">
              <Text className="request-text">{'调用结果：' + result}</Text>
            </View>
          )}
        </View>
        <View className="guide">
          <Text className="headline">新增云函数</Text>
          <Text className="p">
            1. 在云函数根目录 cloudfunctions 上右键选择新建云函数，命名为 sum
          </Text>
          <Text className="p">
            2. 在创建的 cloudfunctions/sum/index.js 文件中添加如下代码
          </Text>
          <Image
            className="image1"
            src={require('../../images/code-func-sum.png')}
            mode="aspectFit"
          ></Image>
          {canIUseClipboard && (
            <Button className="copyBtn" onClick={this.copyCode}>
              复制代码
            </Button>
          )}
          <Text className="p">
            3. 在 cloudfunctions/sum 目录上右键上传并部署
          </Text>
          <Text className="p">4. 点击测试云函数测试</Text>
          <Text className="p">5. 打开云开发云函数管理页，选择 sum 云函数</Text>
          <Text className="p">6. 查看 sum 的调用日志</Text>
          <Text className="p">
            进阶：可在云函数中使用 wx-server-sdk
            操作数据库，文件存储和调用其他云函数，详见文档
          </Text>
        </View>
      </View>
    )
  }
}

export default _C
