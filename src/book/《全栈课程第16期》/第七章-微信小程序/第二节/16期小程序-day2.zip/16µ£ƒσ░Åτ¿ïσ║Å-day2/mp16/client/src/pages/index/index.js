import { Block, View, Button, Text, Image, Navigator } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './index.scss'
//index.js
const app = Taro.getApp()

@withWeapp({
  data: {
    avatarUrl: './user-unlogin.png',
    userInfo: {},
    logged: false,
    takeSession: false,
    requestResult: ''
  },

  onLoad: function() {
    if (!Taro.cloud) {
      Taro.redirectTo({
        url: '../chooseLib/chooseLib'
      })
      return
    }

    // 获取用户信息
    Taro.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          Taro.getUserInfo({
            success: res => {
              this.setData({
                avatarUrl: res.userInfo.avatarUrl,
                userInfo: res.userInfo
              })
            }
          })
        }
      }
    })
  },

  onGetUserInfo: function(e) {
    if (!this.data.logged && e.detail.userInfo) {
      this.setData({
        logged: true,
        avatarUrl: e.detail.userInfo.avatarUrl,
        userInfo: e.detail.userInfo
      })
    }
  },

  onGetOpenid: function() {
    // 调用云函数
    Taro.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)
        app.globalData.openid = res.result.openid
        Taro.navigateTo({
          url: '../userConsole/userConsole'
        })
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
        Taro.navigateTo({
          url: '../deployFunctions/deployFunctions'
        })
      }
    })
  },

  // 上传图片
  doUpload: function() {
    // 选择图片
    Taro.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function(res) {
        Taro.showLoading({
          title: '上传中'
        })

        const filePath = res.tempFilePaths[0]

        // 上传图片
        const cloudPath = 'my-image' + filePath.match(/\.[^.]+?$/)[0]
        Taro.cloud.uploadFile({
          cloudPath,
          filePath,
          success: res => {
            console.log('[上传文件] 成功：', res)

            app.globalData.fileID = res.fileID
            app.globalData.cloudPath = cloudPath
            app.globalData.imagePath = filePath

            Taro.navigateTo({
              url: '../storageConsole/storageConsole'
            })
          },
          fail: e => {
            console.error('[上传文件] 失败：', e)
            Taro.showToast({
              icon: 'none',
              title: '上传失败'
            })
          },
          complete: () => {
            Taro.hideLoading()
          }
        })
      },
      fail: e => {
        console.error(e)
      }
    })
  }
})
class _C extends Taro.Component {
  config = {}

  render() {
    const { avatarUrl, imgUrl } = this.data
    return (
      <View className="container">
        <View className="userinfo">
          <Button
            openType="getUserInfo"
            onGetuserinfo={this.onGetUserInfo}
            className="userinfo-avatar"
            style={'background-image: url(' + avatarUrl + ')'}
            size="default"
          ></Button>
          <View className="userinfo-nickname-wrapper">
            <Button className="userinfo-nickname" onClick={this.onGetOpenid}>
              点击获取 openid
            </Button>
          </View>
        </View>
        {/*  上传图片  */}
        <View className="uploader">
          <View className="uploader-text" onClick={this.doUpload}>
            <Text>上传图片</Text>
          </View>
          {imgUrl && (
            <View className="uploader-container">
              <Image
                className="uploader-image"
                src={imgUrl}
                mode="aspectFit"
                onClick={this.previewImg}
              ></Image>
            </View>
          )}
        </View>
        {/*  操作数据库  */}
        <View className="uploader">
          <Navigator
            url="../databaseGuide/databaseGuide"
            openType="navigate"
            className="uploader-text"
          >
            <Text>前端操作数据库</Text>
          </Navigator>
        </View>
        {/*  即时通信  */}
        <View className="uploader">
          <Navigator
            url="../im/im"
            openType="navigate"
            className="uploader-text"
          >
            <Text>即时通信 Demo</Text>
          </Navigator>
        </View>
        {/*  新建云函数  */}
        <View className="uploader">
          <Navigator
            url="../addFunction/addFunction"
            openType="navigate"
            className="uploader-text"
          >
            <Text>快速新建云函数</Text>
          </Navigator>
        </View>
        {/*  云调用  */}
        <View className="uploader">
          <Navigator
            url="../openapi/openapi"
            openType="navigate"
            className="uploader-text"
          >
            <Text>云调用</Text>
          </Navigator>
        </View>
      </View>
    )
  }
}

export default _C
