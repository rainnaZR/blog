import { Block, View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './deployFunctions.scss'

@withWeapp({
  /**
   * 页面的初始数据
   */
  data: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {}
})
class _C extends Taro.Component {
  config = {
    navigationBarTitleText: '部署云函数'
  }

  render() {
    return (
      <View className="container">
        <View className="list">
          <View className="list-item">
            <Text className="black">调用失败</Text>
          </View>
          <View className="list-item">
            <Text className="request-text">请检查 login 云函数是否已部署</Text>
          </View>
        </View>
        <View className="guide">
          <Text className="headline">部署 login 云函数</Text>
          <Text className="p">1. 确保已通过工具栏云开发入口开通云开发</Text>
          <Text className="p">
            2. 在 cloudfunctions/login 目录上右键上传并部署
          </Text>
          <Text className="p">3. 回到首页，重新点击获取 openid</Text>
        </View>
      </View>
    )
  }
} // pages/deployFunctions/deployFunctions.js

export default _C
