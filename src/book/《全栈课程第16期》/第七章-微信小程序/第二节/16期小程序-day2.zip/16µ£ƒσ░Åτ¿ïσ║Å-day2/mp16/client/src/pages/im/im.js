import { Block, View, Text, Navigator } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './im.scss'
const app = Taro.getApp()

@withWeapp({
  data: {},

  onLoad: function(options) {
    if (app.globalData.openid) {
      this.setData({
        openid: app.globalData.openid
      })
    }

    console.group('数据库"实时数据推送"文档')
    console.log(
      'https://developers.weixin.qq.com/miniprogram/dev/wxcloud/guide/database/realtime.html'
    )
    console.groupEnd()
  }
})
class _C extends Taro.Component {
  config = {
    navigationBarTitleText: '数据库指引'
  }

  render() {
    return (
      <View className="container">
        <View className="guide">
          <Text className="headline">即时通信 demo 介绍</Text>
          <Text className="p">
            本 demo 以《聊天室》为例，在此演示如何使用数据库《实时数据推送》能力
          </Text>
          <Text className="p">1. 确保正在使用基础库 2.8.1</Text>
          <Text className="p">2. 打开云开发控制台，进入到数据库管理页</Text>
          <Text className="p">3. 选择添加集合，集合名设置为 chatroom</Text>
          <Text className="p">4. 将集合设置为所有用户可读、仅创建者可写</Text>
          <Text className="p">
            5. 确保IDE增强编译已开启（如无，到工具详情页中开启）
          </Text>
          <Text className="p">6. 点击下方按钮进入聊天室！</Text>
          <Text className="p">
            注1：可使用（菜单栏-工具）多账号调试的功能在工具中模拟多账号登录调试
          </Text>
          <Text className="p">
            注2：实时数据推送的文档链接已在调试器中打印，可打开查看
          </Text>
        </View>
        <View className="uploader">
          <Navigator
            url="./room/room"
            openType="navigate"
            className="uploader-text"
          >
            <Text>进入聊天室</Text>
          </Navigator>
        </View>
      </View>
    )
  }
}

export default _C
