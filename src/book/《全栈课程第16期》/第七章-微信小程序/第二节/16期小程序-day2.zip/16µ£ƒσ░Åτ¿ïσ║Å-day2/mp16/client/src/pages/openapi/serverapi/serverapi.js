import { Block, View, Text, Image } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './serverapi.scss'

@withWeapp({
  data: {
    templateId: '',
    subscribeMessageResult: '',
    requestSubscribeMessageResult: '',
    wxacodeSrc: '',
    wxacodeResult: '',
    showClearWXACodeCache: false
  },

  async getSubscribeMessageTemplate() {
    try {
      const { result } = await Taro.cloud.callFunction({
        name: 'openapi',
        data: {
          action: 'requestSubscribeMessage'
        }
      })

      const templateId = result

      console.warn('[云函数] [openapi] 获取订阅消息模板 调用成功：', templateId)
      this.setData({
        templateId
      })
    } catch (err) {
      Taro.showToast({
        icon: 'none',
        title: '调用失败'
      })
      console.error('[云函数] [openapi] 获取订阅消息模板 调用失败：', err)
    }
  },

  async requestSubscribeMessage() {
    const templateId = this.data.templateId

    if (!templateId) {
      Taro.showModal({
        title: '发送失败',
        content: '请先获取模板 ID',
        showCancel: false
      })
    }

    Taro.requestSubscribeMessage({
      tmplIds: [templateId],
      success: res => {
        if (res[templateId] === 'accept') {
          this.setData({
            requestSubscribeMessageResult: '成功'
          })
        } else {
          this.setData({
            requestSubscribeMessageResult: `失败（${res[templateId]}）`
          })
        }
      },
      fail: err => {
        this.setData({
          requestSubscribeMessageResult: `失败（${JSON.stringify(err)}）`
        })
      }
    })
  },

  sendSubscribeMessage(e) {
    this.setData({
      subscribeMessageResult: ''
    })

    Taro.cloud.callFunction({
      name: 'openapi',
      data: {
        action: 'sendSubscribeMessage',
        templateId: this.data.templateId
      },
      success: res => {
        console.warn('[云函数] [openapi] subscribeMessage.send 调用成功：', res)
        Taro.showModal({
          title: '发送成功',
          content: '请返回微信主界面查看',
          showCancel: false
        })
        Taro.showToast({
          title: '发送成功，请返回微信主界面查看'
        })
        this.setData({
          subscribeMessageResult: JSON.stringify(res.result)
        })
      },
      fail: err => {
        Taro.showToast({
          icon: 'none',
          title: '调用失败'
        })
        console.error(
          '[云函数] [openapi] subscribeMessage.send 调用失败：',
          err
        )
      }
    })
  },

  submitSubscribeMessageForm(e) {
    this.setData({
      subscribeMessageResult: ''
    })

    Taro.cloud.callFunction({
      name: 'openapi',
      data: {
        action: 'sendSubscribeMessage',
        formId: e.detail.formId
      },
      success: res => {
        console.warn('[云函数] [openapi] subscribeMessage.send 调用成功：', res)
        Taro.showModal({
          title: '发送成功',
          content: '请返回微信主界面查看',
          showCancel: false
        })
        Taro.showToast({
          title: '发送成功，请返回微信主界面查看'
        })
        this.setData({
          templateMessageResult: JSON.stringify(res.result)
        })
      },
      fail: err => {
        Taro.showToast({
          icon: 'none',
          title: '调用失败'
        })
        console.error('[云函数] [openapi] templateMessage.send 调用失败：', err)
      }
    })
  },

  onGetWXACode() {
    this.setData({
      wxacodeSrc: '',
      wxacodeResult: '',
      showClearWXACodeCache: false
    })

    // 此处为演示，将使用 localStorage 缓存，正常开发中文件 ID 应存在数据库中
    const fileID = Taro.getStorageSync('wxacodeCloudID')

    if (fileID) {
      // 有云文件 ID 缓存，直接使用该 ID
      // 如需清除缓存，选择菜单栏中的 “工具 -> 清除缓存 -> 清除数据缓存”，或在 Storage 面板中删掉相应的 key
      this.setData({
        wxacodeSrc: fileID,
        wxacodeResult: `从本地缓存中取得了小程序码的云文件 ID`,
        showClearWXACodeCache: true
      })
      console.log(`从本地缓存中取得了小程序码的云文件 ID：${fileID}`)
    } else {
      Taro.cloud.callFunction({
        name: 'openapi',
        data: {
          action: 'getWXACode'
        },
        success: res => {
          console.warn('[云函数] [openapi] wxacode.get 调用成功：', res)
          Taro.showToast({
            title: '调用成功'
          })
          this.setData({
            wxacodeSrc: res.result,
            wxacodeResult: `云函数获取二维码成功`,
            showClearWXACodeCache: true
          })
          Taro.setStorageSync('wxacodeCloudID', res.result)
        },
        fail: err => {
          Taro.showToast({
            icon: 'none',
            title: '调用失败'
          })
          console.error('[云函数] [openapi] wxacode.get 调用失败：', err)
        }
      })
    }
  },

  clearWXACodeCache() {
    Taro.removeStorageSync('wxacodeCloudID')

    this.setData({
      wxacodeSrc: '',
      wxacodeResult: '',
      showClearWXACodeCache: false
    })

    Taro.showToast({
      title: '清除成功'
    })
  }
})
class _C extends Taro.Component {
  config = {}

  render() {
    const {
      templateId,
      requestSubscribeMessageResult,
      subscribeMessageResult,
      wxacodeResult,
      showClearWXACodeCache,
      wxacodeSrc
    } = this.data
    return (
      <View className="container">
        <View className="list">
          <View
            className="list-item"
            onClick={this.getSubscribeMessageTemplate}
          >
            <Text>获取订阅消息模板 ID</Text>
          </View>
          {templateId && (
            <View className="list-item">
              <Text className="request-text">{'模板 ID：' + templateId}</Text>
            </View>
          )}
        </View>
        <View className="list">
          <View className="list-item" onClick={this.requestSubscribeMessage}>
            <Text>获取下发权限</Text>
          </View>
          {requestSubscribeMessageResult && (
            <View className="list-item">
              <Text className="request-text">
                {'获取权限结果：' + requestSubscribeMessageResult}
              </Text>
            </View>
          )}
        </View>
        <View className="list">
          <View className="list-item" onClick={this.sendSubscribeMessage}>
            <Text>发送订阅消息</Text>
          </View>
          {subscribeMessageResult && (
            <View className="list-item">
              <Text className="request-text">
                {'调用结果：' + subscribeMessageResult}
              </Text>
            </View>
          )}
        </View>
        <View className="guide">
          <Text className="headline">测试须知</Text>
          <Text className="p">1. 需先到小程序管理后台，进入订阅消息管理</Text>
          <Text className="p">2. 在订阅消息管理、公共模板库中添加一个模板</Text>
          <Text className="p">3. 添加完成后在我的模板中点开模板详情</Text>
          <Text className="p">
            4. 根据模板详情修改 openapi 云函数 index.js 中的相应位置
          </Text>
          <Text className="p">
            5. 上传 cloudfunctions 目录下的 openapi 云函数
          </Text>
          <Text className="p">6. 需在手机上预览测试，工具中无效</Text>
          <Text className="p">
            7. 依次点击获取模板、获取下发权限、发送订阅消息
          </Text>
          <Text className="p">
            8. 调用成功后返回到微信主界面查看收到的模板消息
          </Text>
        </View>
        <View className="list">
          <View className="list-item" onClick={this.onGetWXACode}>
            <Text>获取小程序码</Text>
          </View>
          {wxacodeResult && (
            <View className="list-item">
              <Text className="request-text">{wxacodeResult}</Text>
              {showClearWXACodeCache && (
                <Text className="request-text" onClick={this.clearWXACodeCache}>
                  清除缓存
                </Text>
              )}
            </View>
          )}
        </View>
        <View className="guide">
          <Text className="headline">测试须知</Text>
          <Text className="p">
            1. 需上传 cloudfunctions 目录下的 openapi 云函数
          </Text>
          <Text className="p">
            2. 云函数中获取图片后会上传至存储空间并返回至小程序使用和缓存
          </Text>
          <Text className="p">3. 云存储需设置为公有读</Text>
        </View>
        <View className="guide">
          <Image src={wxacodeSrc} mode="aspectFit"></Image>
        </View>
      </View>
    )
  }
}

export default _C
