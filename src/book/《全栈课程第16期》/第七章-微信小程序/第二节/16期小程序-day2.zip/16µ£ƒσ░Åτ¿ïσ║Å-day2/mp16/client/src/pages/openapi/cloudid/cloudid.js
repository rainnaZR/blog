import { Block, View, Text, Button } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './cloudid.scss'

@withWeapp({
  data: {
    weRunResult: '',
    userInfoResult: ''
  },

  onGetWeRunData() {
    Taro.getWeRunData({
      success: res => {
        Taro.cloud
          .callFunction({
            name: 'echo',
            data: {
              // info 字段在云函数 event 对象中会被自动替换为相应的敏感数据
              info: Taro.cloud.CloudID(res.cloudID)
            }
          })
          .then(res => {
            console.log('[onGetWeRunData] 收到 echo 回包：', res)

            this.setData({
              weRunResult: JSON.stringify(res.result)
            })

            Taro.showToast({
              title: '敏感数据获取成功'
            })
          })
          .catch(err => {
            console.log('[onGetWeRunData] 失败：', err)
          })
      }
    })
  },

  onGetUserInfo(e) {
    console.log(e)
    Taro.cloud
      .callFunction({
        name: 'openapi',
        data: {
          action: 'getOpenData',
          openData: {
            list: [e.detail.cloudID]
          }
        }
      })
      .then(res => {
        console.log('[onGetUserInfo] 调用成功：', res)

        this.setData({
          userInfoResult: JSON.stringify(res.result)
        })

        Taro.showToast({
          title: '敏感数据获取成功'
        })
      })
  }
})
class _C extends Taro.Component {
  config = {}

  render() {
    const { weRunResult, userInfoResult } = this.data
    return (
      <View className="container">
        <View className="guide">
          <Text className="headline">开放数据调用</Text>
          <Text className="p">通过 cloudID 获取敏感开放数据有以下两种方式</Text>
          <Text className="p">1. 小程序端 callFunction 自动获取</Text>
          <Text className="p">2. 通过 wx-server-sdk 获取</Text>
          <Text className="p">以下分别先后展示这两种获取方式</Text>
        </View>
        <View className="uploader">
          <Button className="uploader-text" onClick={this.onGetWeRunData}>
            getWeRunData 敏感数据获取
          </Button>
        </View>
        <View className="guide">
          <Text className="headline">测试须知</Text>
          <Text className="p">1. 公共库版本需大于 2.7.0</Text>
          <Text className="p">2. 请确保 echo 函数已上传</Text>
        </View>
        <View className="guide" style="word-break: break-all">
          {weRunResult}
        </View>
        <View className="uploader">
          <Button
            className="uploader-text"
            openType="getUserInfo"
            onGetuserinfo={this.onGetUserInfo}
          >
            getUserInfo 敏感数据获取
          </Button>
        </View>
        <View className="guide">
          <Text className="headline">测试须知</Text>
          <Text className="p">1. 公共库版本需大于 2.7.0</Text>
          <Text className="p">2. 请确保 openapi 函数已上传</Text>
        </View>
        <View className="guide" style="word-break: break-all">
          {userInfoResult}
        </View>
      </View>
    )
  }
} // miniprogram/pages/openapi/cloudid/cloudid.js

export default _C
