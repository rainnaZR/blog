import { Block, View, Text } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './chooseLib.scss'

@withWeapp({
  /**
   * 页面的初始数据
   */
  data: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {}
})
class _C extends Taro.Component {
  config = {
    navigationBarTitleText: '选择基础库'
  }

  render() {
    return (
      <View className="container">
        <View className="list">
          <View className="list-item">
            <Text className="black">初始化失败</Text>
          </View>
          <View className="list-item">
            <Text className="request-text">
              请使用 2.2.3 或以上的基础库以使用云能力
            </Text>
          </View>
        </View>
      </View>
    )
  }
} // pages/chooseLib/chooseLib.js

export default _C
