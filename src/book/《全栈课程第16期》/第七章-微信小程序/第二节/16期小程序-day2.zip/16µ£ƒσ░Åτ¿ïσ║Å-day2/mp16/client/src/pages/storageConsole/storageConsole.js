import { Block, View, Text, Image } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './storageConsole.scss'
// pages/storageConsole/storageConsole.js

const app = Taro.getApp()

@withWeapp({
  data: {
    fileID: '',
    cloudPath: '',
    imagePath: ''
  },

  onLoad: function(options) {
    const { fileID, cloudPath, imagePath } = app.globalData

    this.setData({
      fileID,
      cloudPath,
      imagePath
    })

    console.group('文件存储文档')
    console.log(
      'https://developers.weixin.qq.com/miniprogram/dev/wxcloud/guide/storage.html'
    )
    console.groupEnd()
  }
})
class _C extends Taro.Component {
  config = {
    navigationBarTitleText: '文件存储指引'
  }

  render() {
    const { fileID, cloudPath, imagePath } = this.data
    return (
      <View className="container">
        <View className="list">
          <View className="list-item" onClick={this.testCgi}>
            <Text className="black">上传成功</Text>
          </View>
          <View className="list-item">
            <Text className="request-text">{'文件 ID：' + fileID}</Text>
          </View>
          <View className="list-item">
            <Text className="request-text">{'云文件路径：' + cloudPath}</Text>
          </View>
          <View className="list-item">
            <Image className="image1" src={imagePath} mode="aspectFit"></Image>
          </View>
        </View>
        <View className="guide">
          <Text className="headline">云开发控制台中管理文件</Text>
          <Text className="p">1. 打开云开发控制台</Text>
          <Image
            className="image1"
            src={require('../../images/console-entrance.png')}
            mode="aspectFit"
          ></Image>
          <Text className="p">2. 切换到文件管理标签页</Text>
          <Text className="p">3. 可查看文件列表、管理权限</Text>
          <Text className="p">
            4. 详细的教程和 API 文件，可点击调试器中打印的链接查看
          </Text>
        </View>
      </View>
    )
  }
}

export default _C
