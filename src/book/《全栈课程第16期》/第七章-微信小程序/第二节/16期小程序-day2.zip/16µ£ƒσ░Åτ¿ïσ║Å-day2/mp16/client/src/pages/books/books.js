import { Block, Text, View } from "@tarojs/components";
import Taro from "@tarojs/taro";
import withWeapp from "@tarojs/with-weapp";
// import "./books.scss";
import { AtButton, AtCard } from "taro-ui";

// miniprogram/pages/books/books.js
const db = Taro.cloud.database();

@withWeapp({
  /**
   * 页面的初始数据
   */
  data: {
    array: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    db.collection("books16").get({
      success: (res) => {
        console.log(res);
        this.setData({
          array: res.data,
        });
      },
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {},
})
class _C extends Taro.Component {
  config = {
    navigationBarTitleText: "图书列表",
  };

  render() {
    const { array } = this.data;
    return (
      <Block>
        <Text>图书列表</Text>
        {array.map((item, index) => {
          return (
            <AtCard
              note="小Tips"
              extra={index}
              title={item.title}
              thumb={item.image}
            >
              这也是内容区 可以随意定义功能
            </AtCard>
          );
        })}
        <AtButton>按钮文案</AtButton>
        <AtButton type="primary">按钮文案</AtButton>
        <AtButton type="secondary">按钮文案</AtButton>
      </Block>
    );
  }
}

export default _C;
