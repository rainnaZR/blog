import { Block, View, Text, Image } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './userConsole.scss'

@withWeapp({
  data: {
    openid: ''
  },

  onLoad: function(options) {
    this.setData({
      openid: Taro.getApp().globalData.openid
    })
  }
})
class _C extends Taro.Component {
  config = {
    navigationBarTitleText: '用户管理指引'
  }

  render() {
    const { openid } = this.data
    return (
      <View className="container">
        <View className="list">
          <View className="list-item" onClick={this.testCgi}>
            <Text className="request-text">用户 openid 获取成功</Text>
          </View>
          <View className="list-item" onClick={this.testCgi}>
            <Text className="request-text">{openid}</Text>
          </View>
        </View>
        {/*  云开发用户管理指引  */}
        <View className="guide">
          <Text className="headline">云开发管理用户</Text>
          <Text className="p">1. 打开云开发控制台</Text>
          <Image
            className="image1"
            src={require('../../images/console-entrance.png')}
            mode="aspectFit"
          ></Image>
          <Text className="p">2. 切换到 "用户管理" 标签页</Text>
          <Text className="p">3. 查看访问小程序的用户列表</Text>
        </View>
      </View>
    )
  }
} // pages/userConsole/userConsole.js

export default _C
