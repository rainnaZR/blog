import { Block, View, Text, Button, Image } from '@tarojs/components'
import Taro from '@tarojs/taro'
import withWeapp from '@tarojs/with-weapp'
import './databaseGuide.scss'
// pages/databaseGuide/databaseGuide.js

const app = Taro.getApp()

@withWeapp({
  data: {
    step: 1,
    counterId: '',
    openid: '',
    count: null,
    queryResult: ''
  },

  onLoad: function(options) {
    if (app.globalData.openid) {
      this.setData({
        openid: app.globalData.openid
      })
    }
  },

  onAdd: function() {
    // const db = wx.cloud.database()
    // db.collection('counters').add({
    //   data: {
    //     count: 1
    //   },
    //   success: res => {
    //     // 在返回结果中会包含新创建的记录的 _id
    //     this.setData({
    //       counterId: res._id,
    //       count: 1
    //     })
    //     wx.showToast({
    //       title: '新增记录成功',
    //     })
    //     console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
    //   },
    //   fail: err => {
    //     wx.showToast({
    //       icon: 'none',
    //       title: '新增记录失败'
    //     })
    //     console.error('[数据库] [新增记录] 失败：', err)
    //   }
    // })
  },

  onQuery: function() {
    // const db = wx.cloud.database()
    // // 查询当前用户所有的 counters
    // db.collection('counters').where({
    //   _openid: this.data.openid
    // }).get({
    //   success: res => {
    //     this.setData({
    //       queryResult: JSON.stringify(res.data, null, 2)
    //     })
    //     console.log('[数据库] [查询记录] 成功: ', res)
    //   },
    //   fail: err => {
    //     wx.showToast({
    //       icon: 'none',
    //       title: '查询记录失败'
    //     })
    //     console.error('[数据库] [查询记录] 失败：', err)
    //   }
    // })
  },

  onCounterInc: function() {
    // const db = wx.cloud.database()
    // const newCount = this.data.count + 1
    // db.collection('counters').doc(this.data.counterId).update({
    //   data: {
    //     count: newCount
    //   },
    //   success: res => {
    //     this.setData({
    //       count: newCount
    //     })
    //   },
    //   fail: err => {
    //     icon: 'none',
    //     console.error('[数据库] [更新记录] 失败：', err)
    //   }
    // })
  },

  onCounterDec: function() {
    // const db = wx.cloud.database()
    // const newCount = this.data.count - 1
    // db.collection('counters').doc(this.data.counterId).update({
    //   data: {
    //     count: newCount
    //   },
    //   success: res => {
    //     this.setData({
    //       count: newCount
    //     })
    //   },
    //   fail: err => {
    //     icon: 'none',
    //     console.error('[数据库] [更新记录] 失败：', err)
    //   }
    // })
  },

  onRemove: function() {
    // if (this.data.counterId) {
    //   const db = wx.cloud.database()
    //   db.collection('counters').doc(this.data.counterId).remove({
    //     success: res => {
    //       wx.showToast({
    //         title: '删除成功',
    //       })
    //       this.setData({
    //         counterId: '',
    //         count: null,
    //       })
    //     },
    //     fail: err => {
    //       wx.showToast({
    //         icon: 'none',
    //         title: '删除失败',
    //       })
    //       console.error('[数据库] [删除记录] 失败：', err)
    //     }
    //   })
    // } else {
    //   wx.showToast({
    //     title: '无记录可删，请见创建一个记录',
    //   })
    // }
  },

  nextStep: function() {
    // 在第一步，需检查是否有 openid，如无需获取
    if (this.data.step === 1 && !this.data.openid) {
      Taro.cloud.callFunction({
        name: 'login',
        data: {},
        success: res => {
          app.globalData.openid = res.result.openid
          this.setData({
            step: 2,
            openid: res.result.openid
          })
        },
        fail: err => {
          Taro.showToast({
            icon: 'none',
            title: '获取 openid 失败，请检查是否有部署 login 云函数'
          })
          console.log(
            '[云函数] [login] 获取 openid 失败，请检查是否有部署云函数，错误信息：',
            err
          )
        }
      })
    } else {
      const callback =
        this.data.step !== 6
          ? function() {}
          : function() {
              console.group('数据库文档')
              console.log(
                'https://developers.weixin.qq.com/miniprogram/dev/wxcloud/guide/database.html'
              )
              console.groupEnd()
            }

      this.setData(
        {
          step: this.data.step + 1
        },
        callback
      )
    }
  },

  prevStep: function() {
    this.setData({
      step: this.data.step - 1
    })
  },

  goHome: function() {
    const pages = Taro.getCurrentPages()
    if (pages.length === 2) {
      Taro.navigateBack()
    } else if (pages.length === 1) {
      Taro.redirectTo({
        url: '../index/index'
      })
    } else {
      Taro.reLaunch({
        url: '../index/index'
      })
    }
  }
})
class _C extends Taro.Component {
  config = {
    navigationBarTitleText: '数据库指引'
  }

  render() {
    const { step, openid, counterId, queryResult, count } = this.data
    return (
      <View className="container">
        <View className="list">
          <View className="list-item">
            <Text className="request-text">数据库指引</Text>
          </View>
          <View className="list-item">
            {(7).map((item, index) => {
              return (
                <Text
                  className="request-text"
                  style={'color: ' + (step === index + 1 ? 'red' : 'black')}
                >
                  {index + 1}
                </Text>
              )
            })}
          </View>
          {openid && (
            <View className="list-item">
              <Text className="request-text">{'openid：' + openid}</Text>
            </View>
          )}
          {counterId && (
            <View className="list-item">
              <Text className="request-text">
                {'当前记录 ID：' + counterId}
              </Text>
            </View>
          )}
        </View>
        {/*  快速操作数据库指引  */}
        {/*  简介  */}
        {step === 1 && (
          <View className="guide">
            <Text className="headline">示例介绍</Text>
            <Text className="p">1. 以计数器为例，在此演示如何操作数据库</Text>
            <Text className="p">
              2. 数据库操作大多需要用户 openid，需先配置好 login
              云函数，如已配置好，点击下一步，获取用户 openid 并开始我们的指引
            </Text>
            <Div className="nav">
              <Button
                className="next"
                size="mini"
                type="default"
                onClick={this.nextStep}
              >
                下一步
              </Button>
            </Div>
          </View>
        )}
        {/*  新建集合  */}
        {step === 2 && (
          <View className="guide">
            <Text className="headline">新建集合</Text>
            <Text className="p">1. 打开云开发控制台，进入到数据库管理页</Text>
            <Image
              className="image1"
              src={require('../../images/console-entrance.png')}
              mode="aspectFit"
            ></Image>
            <Text className="p">2. 选择添加集合，集合名为 counters</Text>
            <Image
              className="flat-image"
              src={require('../../images/create-collection.png')}
              mode="aspectFit"
            ></Image>
            <Text className="p">
              3. 可以看到 counters 集合出现在左侧集合列表中
            </Text>
            <Text className="p">注：集合必须在云开发控制台中创建</Text>
            <Div className="nav">
              <Button
                className="prev"
                size="mini"
                type="default"
                onClick={this.prevStep}
              >
                上一步
              </Button>
              <Button
                className="next"
                size="mini"
                type="default"
                onClick={this.nextStep}
              >
                下一步
              </Button>
            </Div>
          </View>
        )}
        {/*  新增记录  */}
        {step === 3 && (
          <View className="guide">
            <Text className="headline">新增记录</Text>
            <Text className="p">
              1. 打开 pages/databaseGuide/databaseGuide.js 文件，定位到 onAdd
              方法
            </Text>
            <Text className="p">2. 把注释掉的代码解除注释</Text>
            <Image
              className="code-image"
              src={require('../../images/code-db-onAdd.png')}
              mode="aspectFit"
            ></Image>
            <Text className="p">
              3. onAdd 方法会往 counters 集合新增一个记录，新增如下格式的一个
              JSON 记录
            </Text>
            <Text className="code">
              {'{'}
              "_id": "数据库自动生成记录 ID 字段", "_openid":
              "数据库自动插入记录创建者的 openid", "count": 1{'}'}
            </Text>
            <Text className="p">4. 点击按钮</Text>
            <Button size="mini" type="default" onClick={this.onAdd}>
              新增记录
            </Button>
            {counterId && (
              <Text className="p">{'新增的记录 _id 为：' + counterId}</Text>
            )}
            <Text className="p">
              5. 在云开发 -> 数据库 -> counters 集合中可以看到新增的记录
            </Text>
            <Div className="nav">
              <Button
                className="prev"
                size="mini"
                type="default"
                onClick={this.prevStep}
              >
                上一步
              </Button>
              {counterId && (
                <Button
                  className="next"
                  size="mini"
                  type="default"
                  onClick={this.nextStep}
                >
                  下一步
                </Button>
              )}
            </Div>
          </View>
        )}
        {/*  查询记录  */}
        {step === 4 && (
          <View className="guide">
            <Text className="headline">查询记录</Text>
            <Text className="p">
              1. 打开 pages/databaseGuide/databaseGuide.js 文件，定位到 onQuery
              方法
            </Text>
            <Text className="p">
              2. 把注释掉的代码解除注释，onQuery 方法会在下方按钮被点击时触发
            </Text>
            <Image
              className="code-image"
              src={require('../../images/code-db-onQuery.png')}
              mode="aspectFit"
            ></Image>
            <Text className="p">3. 点击按钮</Text>
            <Button size="mini" type="default" onClick={this.onQuery}>
              查询记录
            </Button>
            {queryResult && <Text className="code">{queryResult}</Text>}
            <Div className="nav">
              <Button
                className="prev"
                size="mini"
                type="default"
                onClick={this.prevStep}
              >
                上一步
              </Button>
              <Button
                className="next"
                size="mini"
                type="default"
                onClick={this.nextStep}
              >
                下一步
              </Button>
            </Div>
          </View>
        )}
        {/*  更新记录  */}
        {step === 5 && (
          <View className="guide">
            <Text className="headline">更新记录</Text>
            <Text className="p">
              1. 打开 pages/databaseGuide/databaseGuide.js 文件，定位到
              onCounterInc 和 onCounterDec 方法
            </Text>
            <Text className="p">2. 把注释掉的代码解除注释</Text>
            <Image
              className="code-image"
              src={require('../../images/code-db-inc-dec.png')}
              mode="aspectFit"
            ></Image>
            <Text className="p">3. 点击下方按钮更新计数器</Text>
            <Div className="counter">
              <Button
                className="minus"
                size="mini"
                type="default"
                onClick={this.onCounterDec}
              >
                -
              </Button>
              <Text className="p">{count}</Text>
              <Button
                className="plus"
                size="mini"
                type="default"
                onClick={this.onCounterInc}
              >
                +
              </Button>
            </Div>
            <Div className="nav">
              <Button
                className="prev"
                size="mini"
                type="default"
                onClick={this.prevStep}
              >
                上一步
              </Button>
              <Button
                className="next"
                size="mini"
                type="default"
                onClick={this.nextStep}
              >
                下一步
              </Button>
            </Div>
          </View>
        )}
        {/*  删除记录  */}
        {step === 6 && (
          <View className="guide">
            <Text className="headline">删除记录</Text>
            <Text className="p">
              1. 打开 pages/databaseGuide/databaseGuide.js 文件，定位到 onRemove
              方法
            </Text>
            <Text className="p">2. 把注释掉的代码解除注释</Text>
            <Image
              className="code-image"
              src={require('../../images/code-db-onRemove.png')}
              mode="aspectFit"
            ></Image>
            <Text className="p">3. 点击下方按钮删除计数器</Text>
            <Button size="mini" type="default" onClick={this.onRemove}>
              删除记录
            </Button>
            <Div className="nav">
              {counterId && (
                <Button
                  className="prev"
                  size="mini"
                  type="default"
                  onClick={this.prevStep}
                >
                  上一步
                </Button>
              )}
              <Button
                className="next"
                size="mini"
                type="default"
                onClick={this.nextStep}
              >
                下一步
              </Button>
            </Div>
          </View>
        )}
        {/*  结语  */}
        {step === 7 && (
          <View className="guide">
            <Text className="headline">完成指引 !</Text>
            <Text className="p">
              恭喜你，至此已完成数据库操作入门基础，可以点击调试器中的链接，查看详尽的数据库文档
            </Text>
            <Div className="nav">
              <Button
                className="prev"
                size="mini"
                type="default"
                onClick={this.prevStep}
              >
                上一步
              </Button>
              <Button
                className="next"
                size="mini"
                type="default"
                onClick={this.goHome}
              >
                回到首页
              </Button>
            </Div>
          </View>
        )}
      </View>
    )
  }
}

export default _C
