<template>
  <div class="hello">

      <div v-for="item in list" :key="item">
        <div v-html="getItem(item)"></div>
      </div>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  data: () => ({
    list: [
      { type: 'input', value: '邮箱' },
      { type: 'textarea', value: '' },
      { type: 'button', value: '提交' }
    ]
  }),
  methods: {
    getItem(item) {
      switch(item.type) {
        case 'button':
          return `<${item.type}>${item.value}</${item.type}><br/>`
        case 'textarea':
          return `${item.value}<${item.type}></${item.type}><br/>`
        default:
          return `${item.value} <${item.type} /><br/>`;
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
