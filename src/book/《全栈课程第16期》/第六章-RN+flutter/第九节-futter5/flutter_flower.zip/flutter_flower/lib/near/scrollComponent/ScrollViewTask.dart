import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_flower/near/scrollComponent/SingleScrollViewTask.dart';
import 'package:flutter_flower/near/scrollComponent/TableTask.dart';

class ScrollViewTask extends StatelessWidget {
  const ScrollViewTask({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('滚动视图学习'), 
      ),
      body: Center(
        child: Column(
          children: [
            RaisedButton(
              child: Text('SingleChildScrollView'),
              onPressed: (){
                Navigator.push(context, 
                  new MaterialPageRoute(
                    builder: (context) => new SingleChildScrollViewTask()
                  )
                );
              }
            ),
            RaisedButton(
              child: Text('Table'),
              onPressed: (){
                Navigator.push(context, 
                  new MaterialPageRoute(
                    builder: (context) => new TableTask()
                  )
                );
              }
            ),
          ], 
        ),
      ),
    );
  }

}