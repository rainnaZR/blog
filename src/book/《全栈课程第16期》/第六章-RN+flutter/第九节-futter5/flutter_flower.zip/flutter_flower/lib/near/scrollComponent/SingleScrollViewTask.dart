import 'package:flutter/material.dart';

class SingleChildScrollViewTask extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    List<String> list = <String>[];
    for (var i = 0; i < 150; i++) {
      list.add(i.toString());
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('SingleChildScrollView的使用'),
      ),
      body: Center(
        child: Text('SingleChildScrollView')
      ),
    );
  }
}
