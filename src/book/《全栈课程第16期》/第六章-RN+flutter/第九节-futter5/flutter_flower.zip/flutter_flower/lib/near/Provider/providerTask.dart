import 'package:flutter/material.dart';
import 'package:flutter_flower/near/Provider/InheritedWidgetDemo.dart';
import 'package:flutter_flower/near/Provider/ScopedModelDemo.dart';
import 'package:flutter_flower/near/Provider/providerDemo.dart';

class ProviderTask extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Provider'),
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            RaisedButton(
              child: Text('InheritedWidget'),
              onPressed: (){
                Navigator.push(context,
                    new MaterialPageRoute(
                        builder: (context) => new InheritedWidgetDemo()
                    )
                );
              },
            ),
            RaisedButton(
              child: Text('ScopedModel'),
              onPressed: (){
                Navigator.push(context,
                    new MaterialPageRoute(
                        builder: (context) => new ScopedModelDemo()
                    )
                );
              },
            ),
            RaisedButton(
              child: Text('Provider'),
              onPressed: (){
                Navigator.push(context,
                    new MaterialPageRoute(
                        builder: (context) => new ProviderDemo()
                    )
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
