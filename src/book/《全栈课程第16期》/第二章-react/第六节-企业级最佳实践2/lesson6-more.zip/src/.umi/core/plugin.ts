import { Plugin } from '/Users/gaoshaoyun/Documents/kkb-github/16期/lesson6-0305-more/node_modules/@umijs/runtime/dist/index.js';

const plugin = new Plugin({
  validKeys: ['patchRoutes','rootContainer','render','onRouteChange','dva','getInitialState','layout','request',],
});
plugin.register({
  apply: require('/Users/gaoshaoyun/Documents/kkb-github/16期/lesson6-0305-more/src/.umi/plugin-dva/runtime.tsx'),
  path: '/Users/gaoshaoyun/Documents/kkb-github/16期/lesson6-0305-more/src/.umi/plugin-dva/runtime.tsx',
});
plugin.register({
  apply: require('/Users/gaoshaoyun/Documents/kkb-github/16期/lesson6-0305-more/node_modules/@umijs/plugin-initial-state/lib/runtime'),
  path: '/Users/gaoshaoyun/Documents/kkb-github/16期/lesson6-0305-more/node_modules/@umijs/plugin-initial-state/lib/runtime',
});
plugin.register({
  apply: require('/Users/gaoshaoyun/Documents/kkb-github/16期/lesson6-0305-more/node_modules/@umijs/plugin-model/lib/runtime'),
  path: '/Users/gaoshaoyun/Documents/kkb-github/16期/lesson6-0305-more/node_modules/@umijs/plugin-model/lib/runtime',
});

export { plugin };
