import { ApplyPluginsType } from '/Users/gaoshaoyun/Documents/kkb-github/16期/lesson6-0305-more/node_modules/@umijs/runtime/dist/index.js';
import { plugin } from './plugin';

const routes = [
  {
    "path": "/",
    "component": require('/Users/gaoshaoyun/Documents/kkb-github/16期/lesson6-0305-more/src/.umi/plugin-layout/Layout.tsx').default,
    "routes": [
      {
        "path": "/",
        "component": require('@/pages/index').default,
        "exact": true
      },
      {
        "path": "/login",
        "component": require('@/pages/login/index').default,
        "exact": true
      },
      {
        "path": "/more",
        "component": require('@/pages/more/index').default,
        "wrappers": [require('@/wrappers/auth/').default],
        "exact": true
      },
      {
        "path": "/about",
        "component": require('@/pages/about').default,
        "exact": true
      }
    ]
  }
];

// allow user to extend routes
plugin.applyPlugins({
  key: 'patchRoutes',
  type: ApplyPluginsType.event,
  args: { routes },
});

export { routes };
