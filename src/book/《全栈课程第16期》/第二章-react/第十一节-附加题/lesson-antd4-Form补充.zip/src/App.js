import React from "react";
import AntdFormPage from "./pages/AntdFormPage";
import MyRCFieldForm from "./pages/MyRCFieldForm";

export default function App(props) {
  return (
    <div>
      {/* <AntdFormPage /> */}
      <MyRCFieldForm />
    </div>
  );
}
