import React from "react";

const FieldContext = React.createContext();

export default FieldContext;
